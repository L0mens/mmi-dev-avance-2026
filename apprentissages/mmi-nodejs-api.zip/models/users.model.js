const mongoose = require('mongoose');

let validateEmail = function (email) {
    let re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email)
};

const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: 
    {
        type: String,
        minlength: 2,
        maxlength: 40
    },
    email: { 
        type: String, 
        required: true, 
        unique: true,
        validate: [validateEmail, 'Please fill a valid email address']
    },
    password: String
});

userSchema.pre('save', function (next) {
    this.firstName = this.firstName.trim()[0].toUpperCase() + this.firstName.slice(1).toLowerCase();
    this.lastName = this.lastName.toUpperCase();
    next();
})

userSchema.pre("findOneAndUpdate", function (next) {
    this.set({
        firstName: this._update.firstName.trim()[0].toUpperCase() + this._update.firstName.slice(1).toLowerCase(),
        lastName: this._update.lastName.toUpperCase()
    })
    next();
})


const userModel = mongoose.model('Users', userSchema);


module.exports = userModel

