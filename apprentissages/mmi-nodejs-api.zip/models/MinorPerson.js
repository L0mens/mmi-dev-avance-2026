const Person = require("./Person");

class MinorPerson extends Person {

    constructor(name,  age){
        super(name,age)
        
        this.setAge(age)
    }

    setAge(age){
        if(age >= 18)
            throw new Error("Age cannot be >= 18 for a minor")
        this.age=age;
    }

}

module.exports = MinorPerson