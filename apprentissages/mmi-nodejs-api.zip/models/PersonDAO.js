const axios = require('axios');
const Person = require("./Person");
const MinorPerson = require('./MinorPerson');

class PersonDAO {

     getRandom50(){
        return axios.get('https://randomuser.me/api?nat=fr&results=50').then( (resp) => {
            let listPerson = []
            resp.data.results.forEach(element => {
                let p;
                if (element.registered.age < 18)
                    p = new MinorPerson(element.name.first, element.registered.age)
                else
                    p = new Person(element.name.first, element.registered.age)
                listPerson.push(p)
            });
            return listPerson
        });
        
    }
}

module.exports = PersonDAO;