const express = require('express');
const router = express.Router();
const helloController = require('../controllers/hello.controller');

/**
 * @swagger
 * components:
 *   schemas:
 *     Person:
 *       type: object
 *       required:
 *         - age
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           description: Person's name
 *         age:
 *           type: int
 *           description: Person's Age
 *       example:
 *         name: Reno Jackson
 *         age: 65
 */

/**
 * @swagger
 * tags:
 *   name: Person
 *   description: Person's actions
 * /hello/person:
 *   post:
 *     summary: Return a Person's body
 *     tags: [Person]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Person'
 *     responses:
 *       200:
 *         description: The Person.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Person'
 *       500:
 *         description: Some server error
 *
 */


router.get('/', helloController.HelloWorld);

router.get('/hi', helloController.HelloHi);

router.get('/hi/:name', helloController.HelloHiName);

router.post('/person', helloController.personAsJSON);

router.get('/img', helloController.getPersonImg);

router.get('/imgfilename', helloController.getPersonImgFromFileName);

module.exports = router;