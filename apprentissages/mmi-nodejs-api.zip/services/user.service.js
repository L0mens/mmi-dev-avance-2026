const userModel = require('../models/users.model')
const bcrypt = require('bcrypt');

class UserService{

    async getUserByID(id){
        return  await userModel.findOne({ _id : id});
    }

    async getUserByEmail(email){
        return  await userModel.findOne({ email : email});
    }

    async updateUser(id, body){
        await userModel.findOneAndUpdate({ _id : id}, body)
        return await this.getUserByID(id);
    }

    async deleteUser(id){
        return await userModel.deleteOne({ _id : id})
    }

    async createUser(body){
        let user ;
        let userData = structuredClone(body); //Pour éviter de modifier le body
        try {
            let hash = await bcrypt.hash(userData.password, 10)
            userData.password = hash;            
            user = await userModel.create(userData);        
        } catch (error) {
            throw error
        }        
        return user;
    }

    async verifyUserPassword(passwordInput, user){
        let pwdOk = false;
        try {
            pwdOk = await bcrypt.compare(passwordInput, user.password);
        } catch (error) {
            console.log(error);
        }
        return pwdOk;
    }

}

module.exports = UserService;