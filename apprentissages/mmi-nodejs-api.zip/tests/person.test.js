const Person = require('../models/Person')
const MinorPerson = require('../models/MinorPerson')
const PersonDAO = require('../models/PersonDAO');
const request = require('supertest');
const axios = require('axios');
const app = require('../app');

jest.mock('axios');

test('Create a full new Person', () => {
    let p = new Person("JeanTest", 20);
    expect(p.getAge()).toBe(20);
    expect(p.getName()).toBe("JeanTest");
});

test('Create a full new MinorPerson', () => {
    let p = new MinorPerson("JeanMinor", 17);
    expect(p.getAge()).toBe(17);
    expect(p.getName()).toBe("JeanMinor");
    expect(() => p.setAge(20)).toThrow(Error); //On note ici l'appel à une fonction annonyme pour gérer l'erreur
});

test('Get 50 random Person', () => {
    let dao = new PersonDAO();
    const resp = {
        data: {
            results : [
                {
                    name: { title: 'Mr', first: 'Test', last: 'Charles' },
                    dob: { date: '1994-08-21T02:51:26.201Z', age: 31 },
                    registered: { date: '2014-08-05T16:30:40.008Z', age: 18 },
                },
                {
                    name: { title: 'Mr', first: 'Morgan', last: 'Charles' },
                    dob: { date: '1994-08-21T02:51:26.201Z', age: 31 },
                    registered: { date: '2014-08-05T16:30:40.008Z', age: 11 },
                },
                {
                    name: { title: 'Mr', first: 'Jean', last: 'Charles' },
                    dob: { date: '1994-08-21T02:51:26.201Z', age: 31 },
                    registered: { date: '2014-08-05T16:30:40.008Z', age: 25 },
                }

            ]
        }
    };
    axios.get.mockResolvedValue(resp);
     
    let l = dao.getRandom50();
    l.then(data => {
        expect(data.length).toBe(3)
        expect(data[1]).toBeInstanceOf(MinorPerson)
        expect(data[0]).toBeInstanceOf(Person)
    });
});

test('POST /hello/person return a person', async () => {
    const payload = {
        name : "Test",
        age : 18
    }
    const response = await request(app).post('/hello/person')
                .send(payload)
                .set('Content-Type', 'application/json')
                .set('Accept', 'application/json');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ age: 18, name: 'Test' });
});

test('POST /hello/person return a person with no name', async () => {
    const payload = {
        age : 18
    }
    const response = await request(app).post('/hello/person')
                .send(payload)
                .set('Content-Type', 'application/json')
                .set('Accept', 'application/json');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ age: 18, name: 'No name' });
});

test('POST /hello/person return a person without payload', async () => {
    const response = await request(app).post('/hello/person')
                .set('Content-Type', 'application/json')
                .set('Accept', 'application/json');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ age: 0, name: 'No name' });
});