const userModel = require('../models/users.model');
const UserService = require('../services/user.service')
const mongoose = require('mongoose');

describe('insert', () => {
  beforeAll(async () => {
    mongoose.connect('mongodb://127.0.0.1:27017/testtd')
      .catch((err) => console.log(err));
  });

  afterAll(async () => {
    //Permet de clean les collections créées avec cette connexion
    const collections = await mongoose.connection.db.collections()
    for (let collection of collections) {
        await collection.drop()
    }
    await mongoose.disconnect();
  });

  it('should create a user, then get it by email and check ID match', async () => {
    const service = new UserService()
    let newUser = {
        "email" : "aaa@google.com",
        "firstName" : "Jean",
        "lastName" : "Test",
        "password" : "test" 
    }
    let u = await service.createUser(newUser)
    let insertedUser = await service.getUserByEmail("aaa@google.com");
    expect(u.id).toBe(insertedUser.id);
  });
});