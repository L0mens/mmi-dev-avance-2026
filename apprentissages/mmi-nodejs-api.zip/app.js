const express = require('express')
const helloRouter = require('./routes/hello');
const userRouter = require('./routes/user');
const authRouter = require('./routes/auth');
const app = express()
const helmet = require("helmet");
const swaggerJsdoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");


// Parse URL-encoded bodies (Envoyé par les HTML forms)
// Body x-www-url-encoded
app.use(express.urlencoded({ extended: true }));
// Parse JSON bodies (Envoyé par les clients API)
// Body Raw format JSON
app.use(express.json());
// Cela popule le req.body avec les infos envoyé


app.use(helmet())

//Pour préfixer avec /api
// router  = express.Router();
// router.use('/hello', helloRouter);  
// router.use('/users', userRouter);  
// router.use('/auth', authRouter);  
// app.use('/api', router)

app.use('/hello', helloRouter);  
app.use('/users', userRouter);  
app.use('/auth', authRouter);  

app.get('/', (req, res) => {
  res.send('Hello World!')
})

const options = {
  definition: {
    openapi: "3.1.0",
    info: {
      title: "MMI Express API with Swagger",
      version: "0.1.0",
      description:
        "TP de NodeJS. Apprentissage 05",
      license: {
        name: "MIT",
        url: "https://spdx.org/licenses/MIT.html",
      },
      contact: {
        name: "Author",
        url: "https://google.com",
        email: "info@email.com",
      },
    },
    servers: [
      {
        url: "http://localhost:3000",
      },
    ],
  },
  apis: ["./routes/*.js"],
};

const specs = swaggerJsdoc(options);
app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(specs, { explorer: true })
);

module.exports = app