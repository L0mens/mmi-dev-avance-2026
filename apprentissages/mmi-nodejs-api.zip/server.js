
const mongoose = require('mongoose');
const wss = require('./websocketserver');
const app = require('./app')
const port = 3000

mongoose.connect('mongodb://127.0.0.1:27017/td')
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch((err) => console.log(err));

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})