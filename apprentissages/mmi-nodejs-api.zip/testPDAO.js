const DAO = require('./models/PersonDAO');

let d = new DAO();
d.getRandom50().then((l)=> console.log(l))
    