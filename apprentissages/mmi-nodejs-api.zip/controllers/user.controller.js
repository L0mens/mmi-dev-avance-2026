const userModel = require('../models/users.model');
const UserService = require('../services/user.service')
const ObjectId = require('mongoose').Types.ObjectId;

exports.createUser = (req,res) => {
    userModel.create(req.body)
       .then((result) => {
           res.status(201).send({id: result._id});
       })
       .catch((err)=>{
          res.status(400).send(err);
       } );
}

exports.createUserAsync = async (req,res) => {
    let service = new UserService()
    try {
        let user= await service.createUser(req.body);
        res.status(201).send({id: user._id});
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.getUser = async (req,res) => {
    let service = new UserService();
    let statusCode = 200
    try {
        let user;
        if(ObjectId.isValid(req.params.field))
            user= await service.getUserByID(req.params.field);
        else
            user= await service.getUserByEmail(req.params.field);
        if(!user)
            statusCode = 404
        //Vérifie que l'utilisateur qui demande la ressource est bien celui concerné par la ressource
        if(user && user._id != req.auth.userId){
            statusCode = 401
            user = null;
        }
        res.status(statusCode).send({user});
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.deleteUser = async (req,res) => {
    let service = new UserService();
    try {
        await service.deleteUser(req.params.id);
        res.status(204).send({user});
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.updateUser = async (req,res) => {
    let service = new UserService();
    try {
        let user = await service.updateUser(req.params.id, req.body);
        res.status(200).send({user});
    } catch (error) {
        res.status(400).send(error);
    }
}